
#include "Libs/freeglut/include/GL/freeglut.h"
#include <iostream>



// Set initial screen sizes
GLsizei screen_width = 1600;
GLsizei screen_height = 900; 


// Absolute rotation values (0-359 degrees) and rotiation increments for each frame
double rotation_x = 0, rotation_x_increment = 5;
double rotation_y = 0, rotation_y_increment = 5;
double rotation_z = 0, rotation_z_increment = 5;


// angle of rotation for the camera direction
float angle = 0.0;
// actual vector representing the camera's direction

float lx = -2.3f, lz = -2.0f;
// XZ position of the camera
float x = 2.3f, z = 2.0f;



// initilization
void init(void)
{

    // Clear screen color specification
   glClearColor(0.0, 0.0, 0.2, 0.0);
    // Set to dark blue background color
   glShadeModel(GL_SMOOTH); 
   // sets dimensions for the viewport
   glViewport(0,0,screen_width,screen_height); 
   // Setting for projective transformations
   glMatrixMode(GL_PROJECTION); 
   glLoadIdentity(); 
   gluPerspective(45.0f,(GLfloat)screen_width/(GLfloat)screen_height,1.0f,1000.0f); 
   glEnable(GL_DEPTH_TEST); // Enable Z buffer (DEPTH BUFFER)
   glPolygonMode (GL_FRONT_AND_BACK, GL_FILL);
}


  // function to create the walls with given thickness
void drawCube(double thickness)  
{
    glPushMatrix();
    glTranslated(0.05,0.05*thickness,0.05);
    glScaled(1.0,thickness,1.0);
    glutSolidCube(1.0);
    glPopMatrix();
}


// Function to draw circle
void drawCircle(GLfloat xLength, GLfloat yLength, GLfloat radius)
{
    int i;
    
    GLfloat twicePi = 2.0f * 3.142;
    int triAmount = 1000;

    glEnable(GL_LINE_SMOOTH);
    glLineWidth(5.0);

    
    glBegin(GL_LINES);
    glColor4f(1.0f, 1.0f, 1.0f, 0.5f);
    for (i = 0; i <= triAmount; i++)
    {
        glVertex2f(xLength, yLength);
        glVertex2f(xLength + (radius * cos(i * twicePi / triAmount)), yLength + (radius * sin(i * twicePi / triAmount)));
    }
    
    glEnd();
}



//Function to set ambient, Shineness and spec
void setLightsColor(GLfloat ambR, GLfloat ambG, GLfloat ambB,
    GLfloat diffR, GLfloat diffG, GLfloat diffB,
    GLfloat specR, GLfloat specG, GLfloat specB,
    GLfloat shininess) {

    //set variables
    GLfloat ambient[] = { ambR, ambG, ambB };
    GLfloat diffuse[] = { diffR, diffG, diffB };
    GLfloat specular[] = { specR, specG, specB };

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, ambient);
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, diffuse);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, shininess);
}


//
void display(void)
{

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
   
    glOrtho(-1*64/48,1*64/48.0,-1*64/48,1*64/48,0.6,100.0);
    glMatrixMode(GL_MODELVIEW);
   

    glLoadIdentity();


    //used for camera position
    //the first three values represent the camera position
    //2.3, 1.38, 2.0   0.0, 0.25, 0.0
     
    gluLookAt(x, 1.38f, z,
        x + lx, 0.25, z + lz,
        0.0, 1.0, 0.0);
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);


    if (rotation_x > 359) rotation_x = 0;
    if (rotation_y > 359) rotation_y = 0;
    if (rotation_z > 359) rotation_z = 0;

    glRotatef(rotation_x, 1.0, 0.0, 0.0); // Rotations of the object (the model matrix is multiplied by the rotation matrices)
    glRotatef(rotation_y, 0.0, 1.0, 0.0);
    glRotatef(rotation_z, 0.0, 0.0, 1.0);

    
    //Creating a mouse

    glPushMatrix();
    glTranslatef(0.9, .75, .60);
    glScaled(0.4, 0.4, 0.4);
    setLightsColor(1.0, 0.5, 0.5, 1.0, 0.3, 0.3, 0.3, 0.1, 0.0, 1);
    glutSolidCube(0.2);
    glPopMatrix();


    //Creating a glass
    glPushMatrix();
    glTranslatef(0.9, .98, .30);
    glRotated(90.0, 1.0, 0.0, 0.0);
    glScaled(0.4, 0.4, 0.4);
    setLightsColor(1.0, 0.5, 0.5, 1.0, 0.5, 0.5, 0.5, 0.5, 0.2, 1);
    gluCylinder(gluNewQuadric(), 0.1f, 0.1f, 0.5, 5, 5);
    glPopMatrix();



    //Creating a laptop
    glPushMatrix();
    glTranslatef(0.5, .7, .30);
    glScaled(0.7, 0.3, 0.3);
    setLightsColor(1.0, 0.7, 0.7, 1.0, 0.3, 0.7, 0.7, 0.2, 0.0, 1);
    glutSolidCube(0.8);
    glPopMatrix();
    


    //Creating the table
    setLightsColor(0.0, 0.5, 1.0, 0.0, 0.5, 1.0, 1.0, 1.0, 1.0, 50);
    glPushMatrix();
    glRotated(90.0, 1.0, 0.0, 0.0);
    glTranslated(-0.55, -0.65, -0.75);
    drawCircle(1.0, 1.0, 0.8);
    glPopMatrix();
    glRotated(60, 0, 1, 0);
    glPushMatrix();
    glTranslated(0.4,0,0.4);    
    glPopMatrix();

    

    glPushMatrix();
    glRotated(-90.0,1.0,0.0,0.0);
    drawCube(0.02);
    glPopMatrix();
    glRotated(90.0,0.0,0.0,180.0);
    drawCube(0.02);
    glPopMatrix();

    glFlush();
    glutSwapBuffers();

   
}


void keyboard_s(int key, int x, int y)
{

    float fraction = 0.1f;
    switch (key)
    {
    case GLUT_KEY_UP:
        angle -= 0.1f;
        lx = sin(angle);
        lz = -cos(angle);
        break;
        
    case GLUT_KEY_DOWN:
        angle += 0.1;
        lx = sin(angle);
        lz = -cos(angle);
        break;
     
    case GLUT_KEY_LEFT:
        x += lx * fraction;
        z += lz * fraction;
        break;
    case GLUT_KEY_RIGHT:
        x -= lx * fraction;
        z -= lz * fraction;
        break;
    }
}


void cameraNavigator(unsigned char key, int xx, int yy) {

    float fraction = 0.1f;
    switch (key) {
    case 's': case 'S':
        angle -= 0.01f;
        lx = sin(angle);
        lz = -cos(angle);
        break;
    case 'd':case 'D':
        angle += 0.01f;
        lx = sin(angle);
        lz = -cos(angle);
        break;
    case 'e':case 'E':
        x += lx * fraction;
        z += lz * fraction;
        break;
    case 'q':case 'Q':
        x -= lx * fraction;
        z -= lz * fraction;
        break;
    }
}


int main(int argc, char* argv[]) {
   
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB|GLUT_DEPTH);
    glutInitWindowSize(640,480);
    glutInitWindowPosition(0,0);
    glutCreateWindow("Table");
    glutDisplayFunc(display);
    glutIdleFunc(display);
    glutKeyboardFunc(cameraNavigator);
    glutSpecialFunc(keyboard_s);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glShadeModel(GL_SMOOTH);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_NORMALIZE);
    glClearColor(1.0f, 0.0f, 0.0f, 0.0f);
    glViewport(0,0,640,480);
    
    glutMainLoop();
}